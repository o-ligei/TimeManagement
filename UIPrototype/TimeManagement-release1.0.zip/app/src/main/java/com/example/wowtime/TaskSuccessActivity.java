package com.example.wowtime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TaskSuccessActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_success);
    }
}