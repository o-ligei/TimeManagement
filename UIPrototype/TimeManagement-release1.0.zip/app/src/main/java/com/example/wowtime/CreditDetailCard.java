package com.example.wowtime;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreditDetailCard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_detail_card);
    }
}